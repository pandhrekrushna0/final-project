CREATE DATABASE smart_agri_rent;
USE smart_agri_rent;
CREATE TABLE users(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(50),email VARCHAR(50),password VARCHAR(50),role VARCHAR(20));
CREATE TABLE equipment(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(50),price INT,status VARCHAR(20));
CREATE TABLE bookings(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT,equipment_id INT,start_date DATE,end_date DATE,status VARCHAR(20));