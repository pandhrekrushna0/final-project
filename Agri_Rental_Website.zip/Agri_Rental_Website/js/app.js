let cart=[];
function addToCart(name,price){cart.push({name,price});alert(name+' added to cart');localStorage.setItem('cart',JSON.stringify(cart));}
function showCart(){cart=JSON.parse(localStorage.getItem('cart'))||[];let html='';let total=0;cart.forEach(item=>{html+=item.name+' - ₹'+item.price+'<br>';total+=item.price});document.getElementById('cartItems').innerHTML=html;document.getElementById('total').innerText='Total: ₹'+total;}
function login(){alert('Login Successful (Demo)');}